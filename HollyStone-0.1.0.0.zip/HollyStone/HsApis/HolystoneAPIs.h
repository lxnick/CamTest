
#include <dshow.h>	//DirectShow header file for build IBaseFilter


class CHolystoneAPIs
{
public:
	//HolyStone Added for TOF Reg control.
	HRESULT HolystoneAPIs_Init(IBaseFilter** ppSrcFilter, unsigned int devIndex);
	HRESULT TofSensorReg_Read(WORD AddrReg, LONG * Register_Value);
	HRESULT TofSensorReg_Write(WORD AddrReg, LONG Register_Value);
};


