#pragma once

//open one option of the following 3 items
#define DLL_Export
//#define DLL_Import
//#define Lib_Mode

#if defined(DLL_Export)
#define IMPEXP __declspec(dllexport)
#elif defined(DLL_Import) 
#define IMPEXP __declspec(dllimport)
#elif defined(Lib_Mode) 
#define IMPEXP 
#endif 

#define MX			0
#define SST			1
#define PMC			2
#define EON			3
#define AMIC		4
#define ATM			5
#define MX_32Byte	6

enum{
	DL_INITIAL = 20,			//download complete percentage = 0%
	DL_LOOP_RUNNING,			//download complete percentage = 5%~95%
	DL_LOOP_FINISH,				//download complete percentage = 95%
	DL_COMPLETE,				//download complete percentage = 100%
	DL_ERROR,

	SPCA_UNKNOWNIC = 100,
	SPCA_AllIC,
	SPCA_2000BC,
	SPCA_2000D,
	SPCA_2080,
	SPCA_2088,
	SPCA_2082,
	SPCA_2085,
	SPCA_2610,

	SF_UNDEFINED = 120,
	SF_MX25L512,
	SF_SST25VF512,
	SF_PM25LD512,
	SF_PM25LD256,
	SF_PM25LV512,
	SF_AT25F512B,
	SF_EN25F05,
	SF_AMICA25LS512,
	SF_MX25L5121E,
	SF_MX25L1021E,
	SF_GD25Q512,
	SF_FM25F005,
	SF_MD25D512,
	SF_MD25D10,
	SF_MX25L1006E,
	SF_GT25F512,
	SF_EN25F40,

	SF_WriteProtect_UNDEFINED = 150,
	SF_WriteProtect_ON,
	SF_WriteProtect_OFF,

	SP_NOT_EXPECTED_ARGU = 160,
};

class info_camera_os	//get information from software
{
public:
	WORD vid;
	WORD pid;
	WORD bcdDevice;
	BYTE portNum;
	char hubName[MAX_PATH];
	char PDO[MAX_PATH];
};

class info_camera_sf	//get information from hardware
{
public:
	WORD vid;
	WORD pid;
	WORD FWVersion;
	BYTE FWsubVersion;
	BYTE ICType;
	BYTE FlashType;
	BYTE FlashSR;	//status register of serial flash
};


class info_Downloading	//before multiple-burning, must prepare first
{
public:
	IN BYTE newFW[0x10000];
	IN DWORD FW_Length;
	IN BYTE FlashType;
	IN int reset;
	OUT BYTE SW_chksum;
	OUT BYTE FW_chksum;
	OUT BYTE status;
	OUT BYTE percent;
};

class camera
{
public:
	camera();
	~camera();
	// init, un-init
	HRESULT SunplusCam_Init(BYTE icName=SPCA_AllIC,int index=0);
	HRESULT SunplusCam_UnInit();

	// Register
	HRESULT GetASICRegister(WORD addr, BYTE* Reg_Value);
	HRESULT SetASICRegister(WORD addr, BYTE Reg_Value);
	HRESULT GetSensorRegister(WORD addr, WORD* Sensor_Reg_Value);
	HRESULT SetSensorRegister(WORD addr, WORD Sensor_Reg_Value);
	HRESULT GetSensorRegister(BYTE slaveID,WORD addr, WORD* Sensor_Reg_Value);
	HRESULT SetSensorRegister(BYTE slaveID,WORD addr, WORD Sensor_Reg_Value);

	// get backend, flash type 
	HRESULT Get_ASICType(BYTE* type);
	HRESULT Get_FlashType(BYTE* type);

	// serial flash software protect
	HRESULT SetSF_WProtect_ON(BYTE FlashType);
	HRESULT SetSF_WProtect_OFF(BYTE FlashType);
	HRESULT GetSF_WProtect(BYTE* status);
	HRESULT GetSF_SR(BYTE* status);

	// serial flash read/writes
	HRESULT Download_FW(BYTE *FW, DWORD FW_Length, BYTE FlashType,BYTE* SW_chksum=NULL, BYTE* FW_chksum=NULL, BYTE* status=NULL, BYTE* percent=NULL);
	HRESULT Upload_Sector(BYTE *FW, int index, BYTE FlashType);
	HRESULT Upload_FW(BYTE *FW, BYTE FlashType);

	HRESULT GetFWVersion(DWORD* FWVersion);
	HRESULT GetVIDPID(WORD *VID, WORD *PID);
	HRESULT GetSerialNumber(char* serial, BYTE getiSerial=0);


	HRESULT Get_IBaseFilter(VOID** ppFilter);			// get the IBaseFilter of sunplus camera


	HRESULT Get_information_OS(info_camera_os* info);	// get information from operation system
	HRESULT Get_information_SF(info_camera_sf* info);	// get information from serial flash on chip

	HRESULT Fill_Download_info(info_Downloading* info); //before multiple-burning, must prepare first
	HRESULT Download_FW_w_info();						//download with pre-fill information

	HRESULT CompareWithSF(BYTE* Code, int length=0x10000, int* errorPos=NULL);

	class kData;
	kData *hand;


	HRESULT Download_MCM(BYTE *FW, DWORD FW_Length,BYTE* status, BYTE* percent,int rst);
	HRESULT Fill_MCM_Download_info(info_Downloading* info);
	HRESULT Download_MCM_w_info();
	HRESULT SunplusCam_Init_2089(int index=0);
	int GetSubVersion(BYTE *SubVer);

	// write serial number [4/1/2014 frank.chang]
	HRESULT SetSerialNumber(int writeLeng, char* SerialNumber);
};

class m_cam_finder
{
public:
	HRESULT SunplusCam_Init_Multiple(camera* cam_array, int number);
	HRESULT Howmany_Sunplus_Camera(int* number);

	HRESULT SunplusCam_Init_Multiple_2089(camera* cam_array, int number);
	HRESULT Howmany_Sunplus_Camera_2089(int* number);

};
#ifndef Lib_Mode
/************************************************************************/
/*Import / export define                                                */
/************************************************************************/
extern "C" IMPEXP HRESULT WINAPI SunplusCam_Init(void **ppContext);
extern "C" IMPEXP HRESULT WINAPI SunplusCam_Init_IC(BYTE icName=SPCA_AllIC);
extern "C" IMPEXP HRESULT WINAPI SunplusCam_UnInit(void *pContext);

extern "C" IMPEXP HRESULT WINAPI SunplusCam_Init_Multiple(void **ppContext);
extern "C" IMPEXP HRESULT WINAPI SunplusCam_UnInit_Multiple(void *pContext);
extern "C" IMPEXP HRESULT WINAPI SunplusCam_Init_Multiple_2089(void **ppContext);
extern "C" IMPEXP HRESULT WINAPI SunplusCam_UnInit_Multiple_2089(void *pContext);

// Register
extern "C" IMPEXP HRESULT GetASICRegister(BYTE slaveID,WORD addr, BYTE* Reg_Value);
extern "C" IMPEXP HRESULT SetASICRegister(BYTE slaveID,WORD addr, BYTE Reg_Value);
extern "C" IMPEXP HRESULT GetSensorRegister(BYTE slaveID,WORD addr, WORD* Sensor_Reg_Value);
extern "C" IMPEXP HRESULT SetSensorRegister(BYTE slaveID,WORD addr, WORD Sensor_Reg_Value);

// get backend, flash type 
extern "C" IMPEXP HRESULT Get_ASICType(BYTE* type);
extern "C" IMPEXP HRESULT Get_FlashType(BYTE* type);

// serial flash software protect
extern "C" IMPEXP HRESULT SetSF_WProtect_ON(BYTE FlashType);
extern "C" IMPEXP HRESULT SetSF_WProtect_OFF(BYTE FlashType);
extern "C" IMPEXP HRESULT GetSF_WProtect(BYTE* status);

// serial flash read/write
extern "C" IMPEXP HRESULT Download_FW(BYTE *FW, DWORD FW_Length, BYTE FlashType);
extern "C" IMPEXP HRESULT Download_FW_Verbose(BYTE *FW, DWORD FW_Length, BYTE FlashType, BYTE* SW_chksum, BYTE* FW_chksum, BYTE* status, BYTE* percent);
extern "C" IMPEXP HRESULT Upload_Sector(BYTE *FW, int index, BYTE FlashType);
extern "C" IMPEXP HRESULT Upload_FW(BYTE *FW, BYTE FlashType);


// get information	
extern "C" IMPEXP HRESULT GetVIDPID(BYTE slaveID, WORD *VID, WORD *PID);
extern "C" IMPEXP HRESULT GetFWVersion(BYTE slaveID, DWORD *FWVersion);
extern "C" IMPEXP HRESULT GetSerialNumber(BYTE slaveID, char *Serialnum);


extern "C" IMPEXP HRESULT Get_IBaseFilter(VOID** ppFilter);			// get the IBaseFilter of sunplus camera


extern "C" IMPEXP HRESULT Get_information_OS(info_camera_os* info);	// get information from operation system
extern "C" IMPEXP HRESULT Get_information_SF(info_camera_sf* info);	// get information from serial flash on chip

extern "C" IMPEXP HRESULT Fill_Download_info(info_Downloading* info); //before multiple-burning, must prepare first
extern "C" IMPEXP HRESULT Download_FW_w_info();
extern "C" IMPEXP HRESULT CompareWithSF(BYTE* Code, int length, int* errorPos);

extern "C" IMPEXP HRESULT Download_MCM(BYTE *FW, DWORD FW_Length,BYTE* status, BYTE* percent);
extern "C" IMPEXP HRESULT Write_Sector(BYTE *data_4K, int index, BYTE FlashType);

extern "C" IMPEXP HRESULT SetSerialNumber(int writeLeng, char* SerialNumber);

/************************************************************************/
/*Function pointer define                                               */
/************************************************************************/
typedef HRESULT (WINAPI* SunplusCam_Init_Fun)(void **ppContext);
typedef HRESULT (WINAPI* SunplusCam_Init_IC_Fun)(BYTE icName);
typedef HRESULT (WINAPI* SunplusCam_UnInit_Fun)(void *pContext);

typedef HRESULT (*GetASICRegister_Fun)(BYTE slaveID,WORD addr, BYTE* Reg_Value);
typedef HRESULT (*SetASICRegister_Fun)(BYTE slaveID,WORD addr, BYTE Reg_Value);
typedef HRESULT (*GetSensorRegister_Fun)(BYTE slaveID,WORD addr, WORD* Sensor_Reg_Value);
typedef HRESULT (*SetSensorRegister_Fun)(BYTE slaveID,WORD addr, WORD Sensor_Reg_Value);

// get backend, flash type 
typedef HRESULT (*Get_ASICType_Fun)(BYTE* type);
typedef HRESULT (*Get_FlashType_Fun)(BYTE* type);

// serial flash software protect
typedef HRESULT (*SetSF_WProtect_ON_Fun)(BYTE FlashType);
typedef HRESULT (*SetSF_WProtect_OFF_Fun)(BYTE FlashType);
typedef HRESULT (*GetSF_WProtect_Fun)(BYTE* status);
typedef HRESULT (*GetSF_SR_Fun)(BYTE* status);


// serial flash read/write
typedef HRESULT (*Download_FW_Fun)(BYTE *FW, DWORD FW_Length, BYTE FlashType);
typedef HRESULT (*Download_FW_Verbose_Fun)(BYTE *FW, DWORD FW_Length, BYTE FlashType, BYTE* SW_chksum,BYTE* FW_chksum,BYTE* status, BYTE* percent);
typedef HRESULT (*Upload_Sector_Fun)(BYTE *FW, int index, BYTE FlashType);
typedef HRESULT (*Upload_FW_Fun)(BYTE *FW, BYTE FlashType);

// get information
typedef HRESULT (*GetVIDPID_Fun)(BYTE slaveID, WORD *VID, WORD *PID);
typedef HRESULT (*GetFWVersion_Fun)(BYTE slaveID, DWORD *FWVersion);
typedef HRESULT (*GetSerialNumber_Fun)(BYTE slaveID, char *Serialnum);


typedef HRESULT (*Get_IBaseFilter_Fun)(VOID** ppFilter);			// get the IBaseFilter of sunplus camera


typedef HRESULT (*Get_information_OS_Fun)(info_camera_os* info);	// get information from operation system
typedef HRESULT (*Get_information_SF_Fun)(info_camera_sf* info);	// get information from serial flash on chip

typedef HRESULT (*Fill_Download_info_Fun)(info_Downloading* info); //before multiple-burning, must prepare first
typedef HRESULT (*Download_FW_w_info_Fun)();
typedef HRESULT (*CompareWithSF_Fun)(BYTE* Code, int length, int* errorPos);

typedef HRESULT (*Download_MCM_Fun)(BYTE *FW, DWORD FW_Length,BYTE* status, BYTE* percent);
typedef HRESULT (*Write_Sector_Fun)(BYTE *data_4K, int index, BYTE FlashType);

typedef BOOL (*SetDeviceIndex_Fun)(int nSetIdx); //Set device index value = 0~7
typedef HRESULT (*Howmany_Sunplus_Camera_Fun)(int* num);
typedef HRESULT (*Howmany_Sunplus_Camera_2089_Fun)(int* num);

typedef HRESULT (*SetSerialNumber_Fun)(int writeLeng, char* SerialNumber);

typedef HRESULT (WINAPI* SunplusCam_Init_Multiple_Fun)(void **ppContext);
typedef HRESULT (WINAPI* SunplusCam_UnInit_Multiple_Fun)(void *pContext);
typedef HRESULT (WINAPI* SunplusCam_Init_Multiple_2089_Fun)(void **ppContext);
typedef HRESULT (WINAPI* SunplusCam_UnInit_Multiple_2089_Fun)(void *pContext);
#endif 